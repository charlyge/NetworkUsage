package pl.rzagorski.networkstatsmanager.utils;

import pl.rzagorski.networkstatsmanager.model.Package;

/**
 * Created by Robert Zagórski on 2016-12-15.
 */

public interface OnPackageClickListener {

    void onClick(Package packageItem);
}
